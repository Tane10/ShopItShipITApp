var expect = require('chai').expect; 

describe("Main Menu Splash screen", () => {
    describe("Main menu buttons", () => {
        it("Each button should beable to clickable", () => {
            expect(InputFieldClick).to.be.true;
        });
    });
});